package magicsquare;

import java.util.Scanner;

public class MagicSquare {

    public static void main(String[] args) {
        int i, j;
        int sum_row, sum_col, sum_diagnol = 0, sum = 15;
        boolean magic = true;
        int[][] square = new int[3][3];
        
        Scanner input = new Scanner(System.in);
        
        //read number for each cell
        System.out.println("PLEASE INSERT NUMBERS: ");
        System.out.println("    a  b  c - 15");
        System.out.println("    d  e  f - 15");
        System.out.println("    g  h  i - 15");
        System.out.println("  / |  |  | \\");
        System.out.println("15  15 15 15 15");
        
        System.out.println("(Make sure sum of all the number is 15)");
        System.out.println("Enter number of abcdefghi with space in between --> ");
        
        for (i=0; i<3; i++)
            for (j=0; j<3; j++)
                square[i][j] = input.nextInt();
        
        //display square
        System.out.println("Square: ");

        for (i=0; i<3; i++) {
            for (j=0; j<3; j++)
                System.out.print(square[i][j] + " ");
            System.out.println();
        }

        //calculate sum of the first row
        for (j=0; j<3; j++)
            sum += square[0][j];

        //calculate sum of second and third row
        for (i=1; i<3; i++) {
            sum_row = 0;
            for (j=0; j<3; j++)
                sum_row += square[i][j];
            if (sum_row != sum) {
                magic = false;
                break;
            }
        }

        //calculate sum of each column
        if (magic) {
            for (j=0; j<3; j++) {
                sum_col = 0;
                for (i=0; i<3; i++)
                    sum_col += square[i][j];
                if (sum_col != sum) {
                    magic = false;
                    break;
                }
            }
        }

        //calculate sum of first diagnol
        if (magic) {
            for (i=0; i<3; i++)
                for (j=0; j<3; j++)
                    if (i==j)
                        sum_diagnol += square[i][j];
            if (sum_diagnol != sum) {
                magic = false;
            }
        }

        //calculate sum of second diagnol
        if (magic) {
            sum_diagnol = 0;
            for (i=0; i<3; i++)
                for (j=0; j<3; j++)
                    if ((i+j) == 2)
                        sum_diagnol += square[i][j];
            if (sum_diagnol != sum) {
                magic =  false;
            }
        }

        //display result
        if (magic)
            System.out.println("It IS a magic square!");
        else
            System.out.println("It is NOT a magic square.");
    }
}
