import java.util.*;
import java.sql.*;

public class AdminDao {
    
    public static Connection getConnection(){
        Connection con = null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/projectsad", "root", "admin");
        }
        catch (Exception e){
            System.out.println(e);
        }
        
        return con;
    }
    
    public static Admin getUserById(String admin_id){
        Admin e = new Admin();
        
        try{
            Connection con = AdminDao.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM admin WHERE admin_id=?");
            ps.setString(1, admin_id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()){
                e.setAdmin_id(rs.getString(1));
                e.setEmail(rs.getString(2));
                e.setPassword(rs.getString(3));
            }
            con.close();
        }
        catch (Exception ex){
            ex.printStackTrace();
        }
        
        return e;
    }
    
    public static List<Admin> getAllUsers(){
        List<Admin> list = new ArrayList<Admin>();
        
        try{
            Connection con = AdminDao.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM admin");
            ResultSet rs = ps.executeQuery();
            while (rs.next()){
                Admin e = new Admin();
                e.setAdmin_id(rs.getString(1));
                e.setEmail(rs.getString(2));
                e.setPassword(rs.getString(3));
                list.add(e);
            }
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }
    
    public static Admin getUserByEmail(String email){
    Admin e = null;
    try{
        Connection con = AdminDao.getConnection();
        PreparedStatement ps = con.prepareStatement("SELECT * FROM admin WHERE email=?");
        ps.setString(1, email);
        ResultSet rs = ps.executeQuery();
            
        if (rs.next()){
        e = new Admin();
        e.setAdmin_id(rs.getString(1));
        e.setEmail(rs.getString(2));
        e.setPassword(rs.getString(3));
        }
        con.close();
    }
    catch (Exception ex){
        ex.printStackTrace();
    }
    return e;
    }
}
