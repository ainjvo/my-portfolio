/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author user
 */
public class EditServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
               out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Edit Book</title>");
            out.println("<style>");
            out.println("html, body {");
            out.println("    margin: 0;");
            out.println("    padding: 0;");
            out.println("    width: 100%;");
            out.println("    height: 100%;");
            out.println("    font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;");
            out.println("    font-weight: bolder;");
            out.println("    background-color: #D2B48C;");
            out.println("}");
            out.println(".form-container {");
            out.println("    max-width: 800px;");
            out.println("    margin: auto;");
            out.println("    background-color: #F5F5F5;");
            out.println("    padding: 20px;");
            out.println("    border-radius: 10px;");
            out.println("    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);");
            out.println("}");
            out.println(".form-container h1 {");
            out.println("    text-align: center;");
            out.println("    margin-bottom: 20px;");
            out.println("}");
            out.println(".form-group {");
            out.println("    margin-bottom: 15px;");
            out.println("}");
            out.println(".form-group label {");
            out.println("    display: block;");
            out.println("    margin-bottom: 5px;");
            out.println("}");
            out.println(".form-group input {");
            out.println("    width: calc(100% - 20px);");
            out.println("    padding: 10px;");
            out.println("    border: 1px solid #ccc;");
            out.println("    border-radius: 5px;");
            out.println("    font-size: 16px;");
            out.println("}");
            out.println(".form-group input[type='submit'] {");
            out.println("    width: 100%;");
            out.println("    background-color: #1B1212;");
            out.println("    color: white;");
            out.println("    border: none;");
            out.println("    cursor: pointer;");
            out.println("    padding: 10px;");
            out.println("    font-size: 18px;");
            out.println("}");
            out.println(".form-group input[type='submit']:hover {");
            out.println("    background-color: #A18167;");
            out.println("}");
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");
            out.println("<div class='form-container'>");
            out.println("    <h1>Update Book</h1>");

            String sid = request.getParameter("id");
            int id = Integer.parseInt(sid);
            User e = UserDao.getUserById(id);

            out.println("    <form action='EditServlet2' method='post'>");
            out.println("        <input type='hidden' name='id' value='" + e.getId() + "'/>");
            out.println("        <div class='form-group'>");
            out.println("            <label for='title'>Title:</label>");
            out.println("            <input type='text' id='title' name='title' value='" + e.getTitle() + "' required>");
            out.println("        </div>");
            out.println("        <div class='form-group'>");
            out.println("            <label for='bookID'>Book ID:</label>");
            out.println("            <input type='text' id='bookID' name='bookID' value='" + e.getBookID() + "' required>");
            out.println("        </div>");
            out.println("        <div class='form-group'>");
            out.println("            <label for='author'>Author:</label>");
            out.println("            <input type='text' id='author' name='author' value='" + e.getAuthor() + "' required>");
            out.println("        </div>");
            out.println("        <div class='form-group'>");
            out.println("            <label for='price'>Price:</label>");
            out.println("            <input type='text' id='price' name='price' value='" + e.getPrice() + "' required>");
            out.println("        </div>");
            out.println("        <div class='form-group'>");
            out.println("            <label for='genre'>Genre:</label>");
            out.println("            <input type='text' id='genre' name='genre' value='" + e.getGenre() + "' required>");
            out.println("        </div>");
            out.println("        <div class='form-group'>");
            out.println("            <label for='publisher'>Publisher:</label>");
            out.println("            <input type='text' id='publisher' name='publisher' value='" + e.getPublisher() + "' required>");
            out.println("        </div>");
            out.println("        <div class='form-group'>");
            out.println("            <label for='publishdate'>Publish Date:</label>");
            out.println("            <input type='text' id='publishdate' name='publishdate' value='" + e.getPublishdate() + "' placeholder='yyyy-MM-dd' required>");
            out.println("        </div>");
            out.println("        <div class='form-group'>");
            out.println("            <label for='bookLocation'>Book Location:</label>");
            out.println("            <input type='text' id='bookLocation' name='bookLocation' value='" + e.getBooklocation() + "' required>");
            out.println("        </div>");
            out.println("        <div class='form-group'>");
            out.println("            <label for='status'>Status:</label>");
            out.println("            <input type='text' id='status' name='status' value='" + e.getStatus() + "' required>");
            out.println("        </div>");
            out.println("        <div class='form-group'>");
            out.println("            <input type='submit' value='Edit & Save'>");
            out.println("        </div>");
            out.println("    </form>");
            out.println("</div>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}