import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/EditServlet2")
public class EditServlet2 extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String sid = request.getParameter("id");
            int id = Integer.parseInt(sid);  // Get the ID from the request and parse it to an integer

          
            String title = request.getParameter("title");
             String bookID = request.getParameter("bookID");
            String author = request.getParameter("author");
            String priceStr = request.getParameter("price");
            double price = Double.parseDouble(priceStr); 
            String genre = request.getParameter("genre");
            String publisher = request.getParameter("publisher");
            String publishdate = request.getParameter("publishdate");
            String bookLocation = request.getParameter("bookLocation");
            String status = request.getParameter("status");
             
            User e = new User();
            e.setId(id);  // Set the ID in the User object
            e.setBookID(bookID);
            e.setTitle(title);
            e.setAuthor(author);
            e.setPrice(price);
            e.setGenre(genre);
            e.setPublisher(publisher);
            e.setPublishdate(publishdate); 
            e.setBooklocation(bookLocation);
            e.setStatus(status);
            
            int updatestatus = UserDao.update(e);
            if (updatestatus > 0) {
                out.print("<p>Record updated successfully!</p>");
                request.getRequestDispatcher("catalogues.html").include(request, response);
            } else {
                out.println("Sorry! Unable to update record");
            }
            out.close();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
