import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RetrieveServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Retrieve parameters from request
        String category = request.getParameter("category");
        String searchText = request.getParameter("text");

        // Fetch data based on category and searchText using UserDao
        List<User> userList;
        if (category != null && searchText != null) {
            userList = UserDao.getUsersBySearch(category, searchText);
        } else {
            userList = UserDao.getAllUsers();
        }

        // Generate HTML table for response
        out.println("<table>");
        out.println("<tr><th>Book ID</th><th>Title</th><th>Author</th><th>Price</th><th>Genre</th><th>Publisher</th><th>Publish Date</th><th>Book Location</th><th>Status</th></tr>");

        for (User user : userList) {
            out.println("<tr>");
            out.println("<td>" + user.getBookID() + "</td>");
            out.println("<td>" + user.getTitle() + "</td>");
            out.println("<td>" + user.getAuthor() + "</td>");
            out.println("<td>" + user.getPrice() + "</td>");
            out.println("<td>" + user.getGenre() + "</td>");
            out.println("<td>" + user.getPublisher() + "</td>");
            out.println("<td>" + user.getPublishdate() + "</td>");
            out.println("<td>" + user.getBooklocation() + "</td>");
            out.println("<td>" + user.getStatus() + "</td>");
            out.println("</tr>");
        }

        out.println("</table>");
        out.close();
    }
}
