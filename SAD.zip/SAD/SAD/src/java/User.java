
import java.sql.Date;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author user
 */
public class User {
     private int id ;
    private double price;
    private String bookID, title, author, genre, publisher,publishdate, booklocation,status;
    
   
    
    int getId(){
        return id;
    }
    public void setId(int id){
        this.id=id;
    }
    public String getTitle(){
        return title;
    }
    public void setTitle(String title){
        this.title=title;
    }
    public String getBookID(){
        return bookID;
    }
    public void setBookID(String bookID){
        this.bookID=bookID;
    }
    public String getAuthor(){
        return author;
    }
    public void setAuthor(String author){
        this.author=author;
    }
    public Double getPrice(){
        return price;
    }
    public void setPrice(Double price){
        this.price=price;
    }
    public String getGenre(){
        return genre;
    }
    public void setGenre(String genre){
        this.genre=genre;
    }
    public String getPublisher(){
        return publisher;
    }
    public void setPublisher(String publisher){
        this.publisher=publisher;
    }
    public String getPublishdate(){
        return publishdate;
    }
    public void setPublishdate(String publishdate){
        this.publishdate=publishdate;
    }
   
    public String getBooklocation(){
        return booklocation;
    }
    public void setBooklocation(String booklocation){
        this.booklocation=booklocation;
    }
public String getStatus(){
        return status;
    }
    public void setStatus(String status){
        this.status=status;
    }
    

    }
    

