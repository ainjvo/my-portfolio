import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author user
 */
public class UserDao {
    
 public static Connection getConnection(){
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con= DriverManager.getConnection("jdbc:mysql://localhost:3306/projectsad", "root" , "admin");
        System.out.println("Database connection established");
    } catch (Exception e) {
        e.printStackTrace();
    }
    return con;
}
    public static  int  save(User e){
        int savestatus = 0;
        try {
            Connection con=UserDao.getConnection();
            PreparedStatement ps= con.prepareStatement(
                  "insert into user(bookID, title, author, price, genre, publisher, publishdate, booklocation, status) values (?,?,?,?,?,?,?,?,?)");
            ps.setString(1,e.getBookID());
            ps.setString(2,e.getTitle());
            ps.setString(3,e.getAuthor());
            ps.setDouble(4,e.getPrice());
            ps.setString(5,e.getGenre());
            ps.setString(6,e.getPublisher());
            ps.setString(7,e.getPublishdate()); 
            ps.setString(8,e.getBooklocation());
            ps.setString(9,e.getStatus());
              
             savestatus = ps.executeUpdate();
              
             con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        
        }
        return savestatus;
    }
    
   public static int update(User e) {
    int updatestatus = 0;
    try {
        Connection con = UserDao.getConnection();
        PreparedStatement ps = con.prepareStatement(
            "UPDATE user SET bookID=?, title=?, author=?, price=?, genre=?, publisher=?, publishdate=?, booklocation=?, status=? WHERE id=?");
        
        ps.setString(1, e.getBookID());
        ps.setString(2, e.getTitle());
        ps.setString(3, e.getAuthor());
        ps.setDouble(4, e.getPrice());
        ps.setString(5, e.getGenre());
        ps.setString(6, e.getPublisher());
        ps.setString(7, e.getPublishdate());
        ps.setString(8, e.getBooklocation());
        ps.setString(9, e.getStatus());
        ps.setInt(10, e.getId());

        updatestatus = ps.executeUpdate();
        con.close();
    } catch (Exception ex) {
        ex.printStackTrace();
    }
    return updatestatus;
}
    public static int delete(int id) {
        int status = 0;
        try {
            Connection con=UserDao.getConnection();
            PreparedStatement ps=con.prepareStatement("delete from users where id=?");
            ps.setInt(1,id);
            status=ps.executeUpdate();
            
            con.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        return status;
        }
    public static User getUserById(int id){
        User e= new User();
        
        try{
            Connection con = UserDao.getConnection();
            PreparedStatement ps=con.prepareStatement("select * from user where id=?");
            ps.setInt(1,id);
            ResultSet rs=ps.executeQuery();
            if(rs.next()) {
                e.setId(rs.getInt(1));
                e.setBookID(rs.getString(2));
                e.setTitle(rs.getString(3));
                e.setAuthor(rs.getString(4));
                e.setPrice(rs.getDouble(5));
                e.setGenre(rs.getString(6));
                e.setPublisher(rs.getString(7));
               e.setPublishdate(rs.getString(8));
                e.setBooklocation(rs.getString(9));
                 e.setStatus(rs.getString(10));
            }
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    return e;
    }
public static List<User> getAllUsers(){
    List<User> list=new ArrayList<User>();
    
    try{
        Connection con=UserDao.getConnection();
        PreparedStatement ps=con.prepareStatement("select * from user");
        ResultSet rs=ps.executeQuery();
        while(rs.next()) {
            User e=new User();
            e.setId(rs.getInt(1));
            e.setBookID(rs.getString(2));
            e.setTitle(rs.getString(3));
            e.setAuthor(rs.getString(4));
            e.setPrice(rs.getDouble(5));
            e.setGenre(rs.getString(6));
            e.setPublisher(rs.getString(7));
            e.setPublishdate(rs.getString(8));
            e.setBooklocation(rs.getString(9));
             e.setStatus(rs.getString(10));
            list.add(e);
        }
        con.close();
    }catch (Exception e ) {
        e.printStackTrace();
    }
    return list;
}

public static List<User> getUsersBySearch(String searchCategory, String searchText) {
    List<User> list = new ArrayList<>();
    try {
        Connection con = UserDao.getConnection();
        String query = "SELECT * FROM user WHERE " + searchCategory + " LIKE ?";
        PreparedStatement ps = con.prepareStatement(query);
        ps.setString(1, "%" + searchText + "%");
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            User e = new User();
            e.setId(rs.getInt("id"));
            e.setBookID(rs.getString("bookID"));
            e.setTitle(rs.getString("title"));
            e.setAuthor(rs.getString("author"));
            e.setPrice(rs.getDouble("price"));
            e.setGenre(rs.getString("genre"));
            e.setPublisher(rs.getString("publisher"));
            e.setPublishdate(rs.getString("publishdate"));
            e.setBooklocation(rs.getString("booklocation"));
            e.setStatus(rs.getString("status"));
            list.add(e);
        }
        con.close();
    } catch (Exception e) {
        e.printStackTrace();
    }
    return list;
}

}