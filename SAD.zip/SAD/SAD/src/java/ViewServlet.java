import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ViewServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>View Books</title>");
            out.println("<style>");
            out.println("html, body {");
            out.println("    margin: 0;");
            out.println("    padding: 0;");
            out.println("    width: 100%;");
            out.println("    height: 100%;");
            out.println("    font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;");
            out.println("    font-weight: bolder;");
            out.println("    background-color: #D2B48C;");
            out.println("}");
            out.println("body {");
            out.println("    display: flex;");
            out.println("    flex-direction: column;");
            out.println("}");
            out.println(".nav {");
            out.println("    overflow: hidden;");
            out.println("    background-color: #1B1212;");
            out.println("    display: flex;");
            out.println("    justify-content: space-between;");
            out.println("    align-items: center;");
            out.println("}");
            out.println(".nav .rightnav {");
            out.println("    display: flex;");
            out.println("    align-items: center;");
            out.println("}");
            out.println(".nav .rightnav a {");
            out.println("    float: left;");
            out.println("    color: white;");
            out.println("    text-decoration: none;");
            out.println("    text-align: center;");
            out.println("    padding: 37px 42px;");
            out.println("    font-size: 20px;");
            out.println("    cursor: pointer;");
            out.println("}");
            out.println(".nav .rightnav .dropdown {");
            out.println("    position: relative;");
            out.println("    display: inline-block;");
            out.println("}");
            out.println(".nav .rightnav .dropdown-content {");
            out.println("    display: none;");
            out.println("    position: absolute;");
            out.println("    background-color: #1B1212;");
            out.println("    min-width: 160px;");
            out.println("    z-index: 1;");
            out.println("}");
            out.println(".nav .rightnav .dropdown-content a {");
            out.println("    color: white;");
            out.println("    padding: 12px 16px;");
            out.println("    text-decoration: none;");
            out.println("    display: block;");
            out.println("    text-align: left;");
            out.println("}");
            out.println(".nav .rightnav .dropdown-content a:hover {");
            out.println("    background-color: #A18167;");
            out.println("}");
            out.println(".nav .rightnav .dropdown:hover .dropdown-content {");
            out.println("    display: block;");
            out.println("}");
            out.println(".logo img {");
            out.println("    width: 150px;");
            out.println("}");
            out.println("footer {");
            out.println("    background-color: #1B1212;");
            out.println("    color: white;");
            out.println("    text-align: center;");
            out.println("    margin-top: auto;");
            out.println("}");
            out.println("table {");
            out.println("    width: 100%;");
            out.println("    border-collapse: collapse;");
            out.println("    margin: 20px 0;");
            out.println("}");
            out.println("th, td {");
            out.println("    border: 1px solid #5D4037;");
            out.println("    padding: 8px;");
            out.println("    text-align: left;");
            out.println("}");
            out.println("th {");
            out.println("    background-color: #D7CCC8;");
            out.println("}");
            out.println("a {");
            out.println("    color: #8D6E63;");
            out.println("    text-decoration: none;");
            out.println("}");
            out.println("a:hover {");
            out.println("    text-decoration: underline;");
            out.println("}");
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");
            out.println("<div class='nav'>");
            out.println("    <div class='logo'>");
            out.println("        <a href=#none><img src='logo.png'></a>");
            out.println("    </div>");
            out.println("    <div class='rightnav'>");
            out.println("        <div class='dropdown'>");
            out.println("            <a href='javascript:void(0);'>Catalogue</a>");
            out.println("            <div class='dropdown-content'>");
            out.println("                <a href='javascript:void(0);' onclick='showCatalogue()'>Add Book</a>");
            out.println("                <a href='ViewServlet'>View Books</a>");
            out.println("            </div>");
            out.println("        </div>");
            out.println("        <a href='#bookreturn'>Book Return</a>");
            out.println("        <a href='#report'>Report</a>");
            out.println("        <a href='#profile'>Profile</a>");
            out.println("    </div>");
            out.println("</div>");
            out.println("<div class='container'>");
            out.println("    <a href='catalogues.html'>Add New Book</a>");
            out.println("    <h1>Book List</h1>");
            List<User> list = UserDao.getAllUsers();
            out.println("    <table>");
            out.println("        <tr><th>No</th><th>Book ID</th><th>Title</th><th>Author</th><th>Price</th><th>Genre</th><th>Publisher</th><th>Publish Date</th><th>Book Location</th><th>Status</th><th>Edit</th><th>Delete</th></tr>");
            for (User e : list) {
                out.println("        <tr>");
                out.println("            <td>" + e.getId() + "</td>");
                out.println("            <td>" + e.getBookID() + "</td>");
                out.println("            <td>" + e.getTitle() + "</td>");
                out.println("            <td>" + e.getAuthor() + "</td>");
                out.println("            <td>" + e.getPrice() + "</td>");
                out.println("            <td>" + e.getGenre() + "</td>");
                out.println("            <td>" + e.getPublisher() + "</td>");
                out.println("            <td>" + e.getPublishdate() + "</td>");
                out.println("            <td>" + e.getBooklocation() + "</td>");
                out.println("            <td>" + e.getStatus() + "</td>");
                out.println("            <td><a href='EditServlet?id=" + e.getId() + "'>edit</a></td>");
                out.println("            <td><a href='DeleteServlet?id=" + e.getId() + "'>delete</a></td>");
                out.println("        </tr>");
            }
            out.println("    </table>");
            out.println("</div>");
            out.println("<footer>");
            out.println("    &COPY;2024 EVERGREEN LIBRARY");
            out.println("</footer>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
