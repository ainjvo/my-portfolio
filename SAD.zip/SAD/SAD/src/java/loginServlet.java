import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class loginServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String userType = request.getParameter("userType");
        
        if ("staff".equalsIgnoreCase(userType)){
            staff s = staffDao.getUserByEmail(email);
            
            if (s != null && s.getPassword().equals(password)){
                HttpSession session = request.getSession();
                session.setAttribute("staff_id", s.getStaff_id());
                session.setAttribute("staff_name", s.getStaff_name());
                session.setAttribute("email", s.getEmail());
                session.setAttribute("no_phone", s.getNo_phone());
                session.setAttribute("password", s.getPassword());
                session.setAttribute("userType", "staff");
                
                response.sendRedirect("staffProfile.jsp");
            }
            else{
                // Redirect back to login.html with error message
                response.sendRedirect("login.html?errorMessage=Invalid email or password. Please try again.");
            }
        }
        else if ("member".equalsIgnoreCase(userType)){
            member m = memberDao.getUserByEmail(email);
            
            if (m != null && m.getPassword().equals(password)){
                HttpSession session = request.getSession();
                session.setAttribute("member_id", m.getMember_id());
                session.setAttribute("member_name", m.getMember_name());
                session.setAttribute("email", m.getEmail());
                session.setAttribute("no_phone", m.getNo_phone());
                session.setAttribute("password", m.getPassword());
                session.setAttribute("userType", "member");
        
                response.sendRedirect("memberProfile.jsp");
            }
            else{
                // Redirect back to login.html with error message
                response.sendRedirect("login.html?errorMessage=Invalid email or password. Please try again.");
            }
        }
        else if ("manager".equalsIgnoreCase(userType)){
            manager man = managerDao.getUserByEmail(email);
            
            if (man != null && man.getPassword().equals(password)){
                HttpSession session = request.getSession();
                session.setAttribute("manager_id", man.getManager_id());
                session.setAttribute("email", man.getEmail());
                session.setAttribute("userType", "manager");
            
                response.sendRedirect("managerProfile.jsp");
            }
            else{
                // Redirect back to login.html with error message
                response.sendRedirect("login.html?errorMessage=Invalid email or password. Please try again.");
            }
        }
        else if ("admin".equalsIgnoreCase(userType)){
            Admin a = AdminDao.getUserByEmail(email);
            
            if (a != null && a.getPassword().equals(password)){
                HttpSession session = request.getSession();
                session.setAttribute("admin_id", a.getAdmin_id());
                session.setAttribute("email", a.getEmail());
                session.setAttribute("userType", "admin");
            
                response.sendRedirect("adminProfile.jsp");
            }
            else{
                // Redirect back to login.html with error message
                response.sendRedirect("login.html?errorMessage=Invalid email or password. Please try again.");
            }
        }
        else{
            // Redirect back to login.html with error message
            response.sendRedirect("login.html?errorMessage=Invalid user type. Please try again.");
        }
   
        out.close();
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
