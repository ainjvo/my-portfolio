public class manager {
    private String manager_id, email, password;

    public String getManager_id() {
        return manager_id;
    }

    public void setManager_id(String manager_id) {
        this.manager_id = manager_id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    public String getPassword() {
        
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
