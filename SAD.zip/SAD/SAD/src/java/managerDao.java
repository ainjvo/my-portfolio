import java.util.*;
import java.sql.*;

public class managerDao {
    
    public static Connection getConnection(){
        Connection con = null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/projectsad", "root", "admin");
        }
        catch (Exception e){
            System.out.println(e);
        }
        
        return con;
    }
    
    public static manager getUserById(String manager_id){
        manager e = new manager();
        
        try{
            Connection con = managerDao.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM manager WHERE manager_id=?");
            ps.setString(1, manager_id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()){
                e.setManager_id(rs.getString(1));
                e.setEmail(rs.getString(2));
                e.setPassword(rs.getString(3));
            }
            con.close();
        }
        catch (Exception ex){
            ex.printStackTrace();
        }
        
        return e;
    }
    
    public static List<manager> getAllUsers(){
        List<manager> list = new ArrayList<manager>();
        
        try{
            Connection con = managerDao.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM manager");
            ResultSet rs = ps.executeQuery();
            while (rs.next()){
                manager e = new manager();
                e.setManager_id(rs.getString(1));
                e.setEmail(rs.getString(2));
                e.setPassword(rs.getString(3));
                list.add(e);
            }
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }
    
    public static manager getUserByEmail(String email){
    manager e = null;
    try{
        Connection con = managerDao.getConnection();
        PreparedStatement ps = con.prepareStatement("SELECT * FROM manager WHERE email=?");
        ps.setString(1, email);
        ResultSet rs = ps.executeQuery();
            
        if (rs.next()){
        e = new manager();
        e.setManager_id(rs.getString(1));
        e.setEmail(rs.getString(2));
        e.setPassword(rs.getString(3));
        }
        con.close();
    }
    catch (Exception ex){
        ex.printStackTrace();
    }
    return e;
    }
}
