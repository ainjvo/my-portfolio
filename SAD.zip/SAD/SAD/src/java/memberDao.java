import java.util.*;
import java.sql.*;

public class memberDao {
    
    public static Connection getConnection(){
        Connection con = null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/projectsad", "root", "admin");
        }
        catch (Exception e){
            System.out.println(e);
        }
        
        return con;
    }
    
    public static int save(member e){
        int status = 0;
        try{
            Connection con = memberDao.getConnection();
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO member(member_name, email, no_phone, password) VALUES (?, ?, ?, ?)");
            ps.setString(1, e.getMember_name());
            ps.setString(2, e.getEmail());
            ps.setString(3, e.getNo_phone());
            ps.setString(4, e.getPassword());
            
            status = ps.executeUpdate();
            
            con.close();
        }
        catch (Exception ex){
            ex.printStackTrace();
        }
        
        return status;
    }
    
    public static int update(member e){
        int status = 0;
        try{
            Connection con = memberDao.getConnection();
            PreparedStatement ps = con.prepareStatement(
                    "UPDATE member SET member_name=?, email=?, no_phone=?, password=? where member_id=?");
            ps.setString(1, e.getMember_name());
            ps.setString(2, e.getEmail());
            ps.setString(3, e.getNo_phone());
            ps.setString(4, e.getPassword());
            ps.setInt(5, e.getMember_id());
            
            status = ps.executeUpdate();
            
            con.close();
        }
        catch (Exception ex){
            ex.printStackTrace();
        }
        
        return status;
    }
    
    public static int delete(int member_id){
        int status = 0;
        try{
            Connection con = memberDao.getConnection();
            PreparedStatement ps = con.prepareStatement("DELETE FROM member WHERE member_id=?");
            ps.setInt(1, member_id);
            status = ps.executeUpdate();
            
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        
        return status;
    }
    
    public static member getUserById(int member_id){
        member e = new member();
        
        try{
            Connection con = memberDao.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM member WHERE member_id=?");
            ps.setInt(1, member_id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()){
                e.setMember_id(rs.getInt(1));
                e.setMember_name(rs.getString(2));
                e.setEmail(rs.getString(3));
                e.setNo_phone(rs.getString(4));
                e.setPassword(rs.getString(5));
            }
            con.close();
        }
        catch (Exception ex){
            ex.printStackTrace();
        }
        
        return e;
    }
    
    public static List<member> getAllUsers(){
        List<member> list = new ArrayList<member>();
        
        try{
            Connection con = memberDao.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM member");
            ResultSet rs = ps.executeQuery();
            while (rs.next()){
                member e = new member();
                e.setMember_id(rs.getInt(1));
                e.setMember_name(rs.getString(2));
                e.setEmail(rs.getString(3));
                e.setNo_phone(rs.getString(4));
                e.setPassword(rs.getString(5));
                list.add(e);
            }
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }
    
    public static member getUserByEmail(String email){
    member e = null;
    try{
        Connection con = memberDao.getConnection();
        PreparedStatement ps = con.prepareStatement("SELECT * FROM member WHERE email=?");
        ps.setString(1, email);
        ResultSet rs = ps.executeQuery();
            
        if (rs.next()){
            e = new member();
            e.setMember_id(rs.getInt(1));
            e.setMember_name(rs.getString(2));
            e.setEmail(rs.getString(3));
            e.setNo_phone(rs.getString(4));
            e.setPassword(rs.getString(5));
        }
        con.close();
    }
    catch (Exception ex){
        ex.printStackTrace();
    }
    return e;
    }
}
