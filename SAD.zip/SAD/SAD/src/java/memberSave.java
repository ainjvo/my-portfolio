import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class memberSave extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");

        String member_name = request.getParameter("member_name");
        String email = request.getParameter("email");
        String no_phone = request.getParameter("no_phone");
        String password = request.getParameter("password");

        boolean hasError = false;

        // Check if the email already exists
        member existingMember = memberDao.getUserByEmail(email);
        if (existingMember != null) {
            request.setAttribute("emailError", "Email is already registered.");
            hasError = true;
        }

        // Check if the password is at least 5 characters long
        if (password.length() < 5) {
            request.setAttribute("passwordError", "Password must be at least 5 characters long.");
            hasError = true;
        }

        // Preserve user input
        request.setAttribute("member_name", member_name);
        request.setAttribute("email", email);
        request.setAttribute("no_phone", no_phone);

        if (hasError) {
            request.getRequestDispatcher("signupMember.jsp").forward(request, response);
            return; // Stop further processing
        }

        member e = new member();
        e.setMember_name(member_name);
        e.setEmail(email);
        e.setNo_phone(no_phone);
        e.setPassword(password);

        int status = memberDao.save(e);
        if (status > 0) {
            request.setAttribute("successMessage", "Record saved successfully!");
        } else {
            request.setAttribute("errorMessage", "Sorry! Unable to save record.");
        }

        request.getRequestDispatcher("signupMember.jsp").forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
