import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class memberUpdateProfile extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        HttpSession session = request.getSession();
        String currentEmail = (String) session.getAttribute("email");
        
        if (currentEmail == null){
            response.sendRedirect("login.html");
            return;
        }
        
        int member_id = memberDao.getUserByEmail(currentEmail).getMember_id();
        String member_name = request.getParameter("member_name");
        String email = request.getParameter("email");
        String no_phone = request.getParameter("no_phone");
        String password = request.getParameter("password");
        
        member updatedMember = new member();
        updatedMember.setMember_id(member_id);
        updatedMember.setMember_name(member_name);
        updatedMember.setEmail(email);
        updatedMember.setNo_phone(no_phone);
        updatedMember.setPassword(password);
        
        int status = memberDao.update(updatedMember);
        if (status > 0){
            session.setAttribute("member_name", member_name);
            session.setAttribute("email", email);
            session.setAttribute("no_phone", no_phone);
            session.setAttribute("password", password);
            response.sendRedirect("memberProfile.jsp");
        }
        else{
            out.println("Sorry! unable to update profile");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
