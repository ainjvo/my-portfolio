import java.util.*;
import java.sql.*;

public class staffDao {
    
    public static Connection getConnection(){
        Connection con = null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/projectsad", "root", "admin");
        }
        catch (Exception e){
            System.out.println(e);
        }
        
        return con;
    }
    
    public static int save(staff e){
        int status = 0;
        try{
            Connection con = staffDao.getConnection();
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO staff(staff_id, staff_name, email, no_phone, password) VALUES (?, ?, ?, ?, ?)");
            ps.setString(1, e.getStaff_id());
            ps.setString(2, e.getStaff_name());
            ps.setString(3, e.getEmail());
            ps.setString(4, e.getNo_phone());
            ps.setString(5, e.getPassword());
            
            status = ps.executeUpdate();
            
            con.close();
        }
        catch (Exception ex){
            ex.printStackTrace();
        }
        
        return status;
    }
    
    public static int update(staff e){
        int status = 0;
        try{
            Connection con = staffDao.getConnection();
            PreparedStatement ps = con.prepareStatement(
                    "UPDATE staff SET staff_name=?, email=?, no_phone=?, password=? where staff_id=?");
            ps.setString(1, e.getStaff_name());
            ps.setString(2, e.getEmail());
            ps.setString(3, e.getNo_phone());
            ps.setString(4, e.getPassword());
            ps.setString(5, e.getStaff_id());
            
            status = ps.executeUpdate();
            
            con.close();
        }
        catch (Exception ex){
            ex.printStackTrace();
        }
        
        return status;
    }
    
    public static int delete(String staff_id){
        int status = 0;
        try{
            Connection con = staffDao.getConnection();
            PreparedStatement ps = con.prepareStatement("DELETE FROM staff WHERE staff_id=?");
            ps.setString(1, staff_id);
            status = ps.executeUpdate();
            
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        
        return status;
    }
    
    public static staff getUserById(String staff_id){
        staff e = new staff();
        
        try{
            Connection con = staffDao.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM staff WHERE staff_id=?");
            ps.setString(1, staff_id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()){
                e.setStaff_id(rs.getString(1));
                e.setStaff_name(rs.getString(2));
                e.setEmail(rs.getString(3));
                e.setNo_phone(rs.getString(4));
                e.setPassword(rs.getString(5));
            }
            con.close();
        }
        catch (Exception ex){
            ex.printStackTrace();
        }
        
        return e;
    }
    
    public static List<staff> getAllUsers(){
        List<staff> list = new ArrayList<staff>();
        
        try{
            Connection con = staffDao.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM staff");
            ResultSet rs = ps.executeQuery();
            while (rs.next()){
                staff e = new staff();
                e.setStaff_id(rs.getString(1));
                e.setStaff_name(rs.getString(2));
                e.setEmail(rs.getString(3));
                e.setNo_phone(rs.getString(4));
                e.setPassword(rs.getString(5));
                list.add(e);
            }
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }
    
    public static staff getUserByEmail(String email){
    staff e = null;
    try{
        Connection con = staffDao.getConnection();
        PreparedStatement ps = con.prepareStatement("SELECT * FROM staff WHERE email=?");
        ps.setString(1, email);
        ResultSet rs = ps.executeQuery();
            
        if (rs.next()){
        e = new staff();
        e.setStaff_id(rs.getString(1));
        e.setStaff_name(rs.getString(2));
        e.setEmail(rs.getString(3));
        e.setNo_phone(rs.getString(4));
        e.setPassword(rs.getString(5));
        }
        con.close();
    }
    catch (Exception ex){
        ex.printStackTrace();
    }
    return e;
    }
}
