import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class staffEdit extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<h1>Update Staff</h1>");
        
        String staff_id = request.getParameter("staff_id");
        
        staff e = staffDao.getUserById(staff_id);
        
        out.print("<form action='staffEdit2' method='post'>");
        out.print("<table>");
        out.print("<tr><td>Staff ID:</td><td><input type='text' name='staff_id' value='"
            +e.getStaff_id()+"' readonly/></td></tr>");
        out.print("<tr><td>Full Name:</td><td><input type='text' name='staff_name' value='"
            +e.getStaff_name()+"'/></td></tr>");
        out.print("<tr><td>Email:</td><td><input type='email' name='email' value='"
            +e.getEmail()+"'/></td></tr>");
        out.print("<tr><td>Phone Number:</td><td><input type='text' name='no_phone' value='"
            +e.getNo_phone()+"'/></td></tr>");
        out.print("<tr><td>Password:</td><td><input type='password' name='password' value='"
            +e.getPassword()+"'/></td></tr>");
        out.print("<tr><td colspan='2'><input type='submit' value='Edit&Save'/></td></tr>");
        out.print("</table>");
        out.print("</form>");
        
        out.close();
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
